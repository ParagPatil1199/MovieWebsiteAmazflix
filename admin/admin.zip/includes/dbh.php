<?php
$dbservername="localhost";
$dbuser="root";
$dbpass="";
$dbname="tonystark";
$conn=mysqli_connect($dbservername,$dbuser,$dbpass,$dbname);
?>

